
window[window["TiktokAnalyticsObject"]].instance("C4EMCC69UAPKMTRVN41G").setAdvancedMatchingAvailableProperties({"email":false,"phone_number":false});
window[window["TiktokAnalyticsObject"]].instance("C4EMCC69UAPKMTRVN41G").setPixelInfo && window[window["TiktokAnalyticsObject"]].instance("C4EMCC69UAPKMTRVN41G").setPixelInfo({status: 0, name: "Tik Tok Pixel", advertiserID: "6852416487953530886", setupMode: 1, partner: "", is_onsite: false});
window[window["TiktokAnalyticsObject"]].setPCMDomain && window[window["TiktokAnalyticsObject"]].setPCMDomain("digitalocean.com");
window[window["TiktokAnalyticsObject"]].setPCMConfig && window[window["TiktokAnalyticsObject"]].setPCMConfig([]);
